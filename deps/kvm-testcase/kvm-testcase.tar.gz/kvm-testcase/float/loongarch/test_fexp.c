#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <fenv.h>
#include <setjmp.h>
#include <unistd.h>

#define DIV_JMP 1
jmp_buf jmpbuf;

static void fpe(int sig, siginfo_t *info, void *uc)
{
    longjmp(jmpbuf, DIV_JMP);
}

static void setup_signal(void)
{
    struct sigaction sa;
    sa.sa_sigaction = fpe;
    sa.sa_flags = SA_SIGINFO | SA_NODEFER;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGFPE, &sa, NULL);
}

int main()
{
    double i = 1.22222;
    double div = 0.0;
    double ret;
    /* enable float point exception divbyzero */
    feenableexcept(FE_DIVBYZERO);
    setup_signal();
    int jmp = setjmp(jmpbuf);
    if (jmp == 0) {
        ret = i / div;
    } else if (jmp == DIV_JMP) {
        printf("PASS: enable fpe divbyzero\n");
    } else {
        printf("FAIL: enable fpe divbyzero jmp is %d\n", jmp);
	goto failed;
    }

    /* disable float point exception divbyzero */
    fedisableexcept(FE_DIVBYZERO);
    ret = i / div;
    if (*((unsigned long *)&ret) == 0x7ff0000000000000) {
        printf("PASS: disable fpe divbyzero ret is %lx\n", ret);
    } else {
        printf("FAIL: disable fpe divbyzero ret is %lx\n", ret);
	goto failed;
    }
    return 0;
failed:
    return -1;
}

