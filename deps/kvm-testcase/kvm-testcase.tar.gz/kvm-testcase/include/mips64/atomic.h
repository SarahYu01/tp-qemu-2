#ifndef _ATOMIC_TEST_H
#define _ATOMIC_TEST_H

#define LAMO 1
#define MAX_NTHREADS 100
#define __WEAK_LLSC_MB        "       .set mips64r2\nsynci 0\n.set mips0\n"
#define smp_llsc_mb()   __asm__ __volatile__(__WEAK_LLSC_MB : : :"memory")
#define smp_mb__before_llsc() smp_llsc_mb()
#if 0
typedef struct {
    int counter;
    int padding;
} __attribute__((aligned(8))) atomic_t;
#endif

static __inline__ void atomic_set(atomic_t * v, int i)
{
    __asm__ __volatile__(
	    "       .set    mips64r2        # atomic_set            \n"
	    "       .set    noreorder                               \n"
	    "       sync                                            \n"
	    "       sw      %1, %0                                  \n"
	    "       sync                                            \n"
	    "       .set    reorder                                 \n"
	    "       .set    mips0                                   \n"
	    : "+m" (v->counter)
	    : "r" (i));
}
static __inline__ int atomic_add_return(int i, atomic_t * v)
{
	int result;
	int temp;

	do {
		__asm__ __volatile__(
				"       .set    mips3                           \n"
				__WEAK_LLSC_MB
				"       ll      %1, %2  # atomic_add_return     \n"
				"       addu    %0, %1, %3                      \n"
				"       sc      %0, %2                          \n"
				"       .set    mips0                           \n"
				: "=&r" (result), "=&r" (temp), "+m" (v->counter)
				: "Ir" (i));
	} while (unlikely(!result));
	result = temp + i;
	smp_llsc_mb();

	return result;
}

static __inline__ int atomic_sub_return(int i, atomic_t * v)
{
	int result;
	int temp;

	do {
		__asm__ __volatile__(
				"       .set    mips3                           \n"
				__WEAK_LLSC_MB
				"       ll      %1, %2  # atomic_sub_return     \n"
				"       addu    %0, %1, %3                      \n"
				"       sc      %0, %2                          \n"
				"       .set    mips0                           \n"
				: "=&r" (result), "=&r" (temp), "+m" (v->counter)
				: "Ir" (i));
	} while (unlikely(!result));
	result = temp + i;
	smp_llsc_mb();

	return result;
}
extern void *add_and_return(void *id);
extern atomic_t input_no;
extern int *buf;
extern int bufSize;
extern int total_times;
extern int thread_done;
extern int thread_count;
extern int times;
extern int fatal;
extern pthread_mutex_t count_mutex;
extern pthread_cond_t condition_var;

/*
 * parse_r var, r - Helper assembler macro for parsing register names.
 *
 * This converts the register name in $n form provided in \r to the
 * corresponding register number, which is assigned to the variable \var. It is
 * needed to allow explicit encoding of instructions in inline assembly where
 * registers are chosen by the compiler in $n form, allowing us to avoid using
 * fixed register numbers.
 *
 * It also allows newer instructions (not implemented by the assembler) to be
 * transparently implemented using assembler macros, instead of needing separate
 * cases depending on toolchain support.
 *
 * Simple usage example:
 * __asm__ __volatile__("parse_r __rt, %0\n\t"
 *          ".insn\n\t"
 *          "# di    %0\n\t"
 *          ".word   (0x41606000 | (__rt << 16))"
 *          : "=r" (status);
 */

/* Match an individual register number and assign to \var */
#define _IFC_REG(n)             \
    ".ifc   \\r, $" #n "\n\t"       \
"\\var  = " #n "\n\t"           \
".endif\n\t"

/* Match an individual register number and assign to \var */
#define _IFC_REG_1(n)             \
    ".ifc   \\r, $" #n "\n\t"       \
"\\var  = " "30" "\n\t"			\
".endif\n\t"

#define _IFC_REG_2(n)             \
    ".ifc   \\r, $" #n "\n\t"       \
"\\var  = " "29" "\n\t"			\
".endif\n\t"

__asm__(".macro parse_r var r\n\t"
	"\\var  = -1\n\t"
	_IFC_REG(0)  _IFC_REG(1)  _IFC_REG(2)  _IFC_REG(3)
	_IFC_REG(4)  _IFC_REG(5)  _IFC_REG(6)  _IFC_REG(7)
	_IFC_REG(8)  _IFC_REG(9)  _IFC_REG(10) _IFC_REG(11)
	_IFC_REG(12) _IFC_REG(13) _IFC_REG(14) _IFC_REG(15)
	_IFC_REG(16) _IFC_REG(17) _IFC_REG(18) _IFC_REG(19)
	_IFC_REG(20) _IFC_REG(21) _IFC_REG(22) _IFC_REG(23)
	_IFC_REG(24) _IFC_REG(25) _IFC_REG(26) _IFC_REG(27)
	_IFC_REG(28) _IFC_REG(29) _IFC_REG(30) _IFC_REG(31)
	_IFC_REG_1(fp) _IFC_REG_2(sp)
	".iflt  \\var\n\t"
	".error \"Unable to parse register name \\r\"\n\t"
	".endif\n\t"
	".endm");

#undef _IFC_REG
#undef _IFC_REG_1
#undef _IFC_REG_2

#endif /* _ATOMIC_TEST_H */
