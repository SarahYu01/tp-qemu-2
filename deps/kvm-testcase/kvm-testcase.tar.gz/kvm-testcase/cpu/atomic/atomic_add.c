#include "atomic.h"
atomic_t input_no = ATOMIC_INIT(0);

static int add_and_return_test(void)
{
    unsigned long i;
    int val;

    i = 0;
    val = buf[i];
    while ((val == 1) && (i < bufSize)) {
	i++;
	val = buf[i];
    }

    if (i == bufSize)
	return 1;

    return 0;
}

void * add_and_return(void * id)
{
    unsigned long i, j;
    int ret;

    while ((times < total_times) && (fatal == 0)) {
	i = atomic_inc_return(&input_no) - 1;
	while ( i < bufSize) {
	    if (buf[i] == 1) {
		fprintf(stderr, "Add and return failure, counter = %ld\n", i);
		abort();
	    }
	    buf[i] = 1;
	    j = 0;
#if 0
	    while ((j<i) && (buf[j] == 1))
		j++;
	    if (j<i)
		printf("info pos %d skipped \n", j);
#endif
	    i = atomic_inc_return(&input_no) - 1;
	}
	pthread_mutex_lock( &count_mutex );
	thread_done++;
	if (thread_done < thread_count) {
	    pthread_cond_wait(&condition_var, &count_mutex );
	} else {
	    times++;
	    ret = add_and_return_test();
	    if (ret == 0) {
		printf("times %d Failed \n", times);
		fatal = 1;
	    } else {
		printf("times %d passed \n", times);
	    }
	    thread_done = 0;
	    memset(buf, 0, bufSize * sizeof(int));
	    atomic_set(&input_no, 0);
	    pthread_cond_broadcast(&condition_var);
	}
	pthread_mutex_unlock( &count_mutex );
    }
    return 0;
}


