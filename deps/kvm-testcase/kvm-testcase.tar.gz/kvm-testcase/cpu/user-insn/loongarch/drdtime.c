#include <stdio.h>
#include <stdlib.h>
#include <time.h>

unsigned long drdtime(void)
{
	unsigned long count = 0;
	unsigned int coreid = 0;

	__asm__ __volatile__(
			"       rdtime.d %0, %1\n"
			: "=r" (count), "=r"(coreid)
			:
			);

	return count;
}

int main() {
	unsigned long result;

	result = drdtime();
	printf("read_r4k_count result %lx \n", result);
	return 0;
}
