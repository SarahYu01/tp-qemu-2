#include <stdio.h>
#include <stdlib.h>

struct cpucfg_array {
	unsigned int no;
	unsigned int val;
};

struct cpucfg_array cfg[] = {
	{0, 0x14c010},
	{1, 0x3f2f2fe},
	{2, 0x7cc3cf},
	{3, 0xfcff},
	{4, 0x5f5e100},
	{5, 0x10001},
	{6, 0x4033},
	{10, 0x2c3d},
	{11, 0x6080003},
	{12, 0x6080003},
	{13, 0x608000f},
	{14, 0x60f000f},
	{30, 0},
}; 

unsigned int cpucfg(unsigned int no)
{
	register unsigned int cpu_cfg asm ("$4");
	register unsigned int in asm("$4") = no;

	__asm__ __volatile__(
			"cpucfg %0, %1\n"
			: "=r" (cpu_cfg)
			:"r" (in)
			:
			);

	return cpu_cfg;
}

int main() {
	unsigned int result;
	int i;

	for (i = 0; i < sizeof(cfg) / sizeof(struct cpucfg_array); i++) {
		result = cpucfg(cfg[i].no);
		if (result != cfg[i].val)
			printf("cfg %d miscompare %lx origin %lx\n", cfg[i].no, result, cfg[i].val);
	}
	return 0;
}
