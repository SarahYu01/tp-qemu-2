#include <stdio.h>
#include <stdlib.h>

unsigned long read_r4k_count(void)
{       
        unsigned long count;
        
        __asm__ __volatile__(
        "       .set push\n"
        "       .set mips32r2\n"
        "       rdhwr   %0, $2\n"
        "       .set pop\n"
        : "=r" (count));
        
        return count;
}

unsigned long read_r4k_cpunum(void)
{       
        unsigned long count;
        
        __asm__ __volatile__(
        "       .set push\n"
        "       .set mips32r2\n"
        "       rdhwr   %0, $0\n"
        "       .set pop\n"
        : "=r" (count));
        
        return count;
}

unsigned long read_r4k_CCRes(void)
{       
        unsigned long count;
        
        __asm__ __volatile__(
        "       .set push\n"
        "       .set mips32r2\n"
        "       rdhwr   %0, $3\n"
        "       .set pop\n"
        : "=r" (count));
        
        return count;
}

unsigned long read_r4k_nodecount(void)
{
        unsigned long count;

        __asm__ __volatile__(
        "       .set push\n"
        "       .set mips32r2\n"
        "       rdhwr   %0, $30\n"
        "       .set pop\n"
        : "=r" (count));

        return count;
}

unsigned long read_r4k_ncRes(void)
{
        unsigned long count;

        __asm__ __volatile__(
        "       .set push\n"
        "       .set mips32r2\n"
        "       rdhwr   %0, $31\n"
        "       .set pop\n"
        : "=r" (count));

        return count;
}

int main() {
	unsigned long result;

	result = read_r4k_cpunum();
	printf("read_r4k_cpunum result %lx \n", result);

	result = read_r4k_count();
	printf("read_r4k_count result %lx \n", result);

	result = read_r4k_CCRes();
	printf("read_r4k_CCRes result %lx \n", result);

        result = read_r4k_nodecount();
        printf("read_r4k_count result %lx \n", result);

        result = read_r4k_ncRes();
        printf("read_r4k_count result %lx \n", result);
	return 0;
}
