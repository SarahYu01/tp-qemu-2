gcc writemm.c  -g -o writemm -lpthread
