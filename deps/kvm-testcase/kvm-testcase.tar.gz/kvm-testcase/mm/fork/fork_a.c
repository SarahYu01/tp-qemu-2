#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <stdlib.h>

#define SIZE_CHAR 16*1024

#define SIZE_INT 4*1024

int main()
{
	pid_t pid, pid_now, ppid;
	int i, j, cont;
	unsigned int *mem, *pt;
	ppid = getpid();
	for (i = 0; i < 20; i++) {
		pid = fork();
		if (pid < 0) {
			perror("fork error!\n");
			return 0;
		}
		if (pid == 0) {
			pid_now = getpid();
			printf("child thread %d\n", getpid());

			mem = malloc(SIZE_CHAR);
			if (mem == NULL) {
				printf("pid:%d: malloc error!\n",
						getpid());
				return 0;
			}

			pt = mem;

			for (j = 0; j < SIZE_INT; j++) {
				*(pt + j) = pid_now + j;
			}
			for (j = 0; j < SIZE_INT; j++) {
				if (*(pt + j) != (pid_now + j)) {
					perror("data error!\n");
				}
			}

			free(mem);
		}
	}
	if (ppid == getpid()) {
		for (i = 0; i < 20; i++) {
			wait(NULL);
		}
	}

	return 0;
}
