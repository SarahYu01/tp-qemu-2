gcc readmm.c  -O2 -o readmm -lpthread
