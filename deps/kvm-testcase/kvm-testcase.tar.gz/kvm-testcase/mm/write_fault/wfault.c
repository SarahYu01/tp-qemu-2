#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <sys/sysinfo.h>

typedef void * (* thr_func)(void *);
typedef int (* test_func)(void);    /* Returns != 0 on success */

int *buf;
int bufSize = 0x8000000;
int total_times = 0x1000;
int thread_done = 0;
int thread_count = 4;
int times = 0;
int fatal = 0;
int pagesize;
pthread_mutex_t count_mutex     = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t  condition_var   = PTHREAD_COND_INITIALIZER;
int sum;

#define MAX_NTHREADS 100
void * run_parallel(int nthreads, thr_func f1, const char *name)
{ 
    pthread_attr_t attr;
    pthread_t thr[MAX_NTHREADS];
    int i;

    printf("Testing %s\n", name);
    if (nthreads > MAX_NTHREADS) {
        fprintf(stderr, "run_parallel: requested too many threads\n");
        abort();
    }

    pthread_attr_init(&attr);
    for (i = 0; i < nthreads; ++i) {
        int code = pthread_create(thr + i, &attr, f1, (void *)(long)i);
        if (code != 0)
        {
            fprintf(stderr, "pthread_create returned %d, thread %d\n", code, i);
            abort();
        }
    }
    for (i = 0; i < nthreads; ++i) {
        int code = pthread_join(thr[i], NULL);
        if (code != 0)
        {
            fprintf(stderr, "pthread_join returned %d, thread %d\n", code, i);
            abort();
        }
    }
    return 0;
}

void * access_mm(void * id)
{
        unsigned long i, j;
        int ret;

	sum = 0;
	i = 0;
        while ((times < total_times) && (fatal == 0)) {
                while ( i < bufSize) {
			sum += buf[i];
			buf[i] = i;
			i +=  pagesize;
                }
                pthread_mutex_lock( &count_mutex );
                thread_done++;
                if (thread_done < thread_count) {
                        pthread_cond_wait(&condition_var, &count_mutex );
                } else {
			if ((times % 10) == 0)
				printf("times %d \n", times);
                        times++;
                        thread_done = 0;
			free(buf);
			buf = NULL;
			buf = malloc(bufSize * sizeof(int));
                        pthread_cond_broadcast(&condition_var);
                }
                pthread_mutex_unlock( &count_mutex );
        }
        return 0;
}

int main(void)
{
    pagesize = getpagesize();
    pagesize = pagesize / sizeof(int);
    thread_count = get_nprocs() * 2;

    buf = malloc(bufSize * sizeof(int));
    run_parallel(thread_count, access_mm, "access_mm");
    free(buf);

    printf("value of sum %d \n", sum);
    return 0;
}

