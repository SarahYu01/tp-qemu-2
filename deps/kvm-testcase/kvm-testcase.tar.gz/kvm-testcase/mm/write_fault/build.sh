gcc writemm.c  -O2 -o writemm -lpthread
