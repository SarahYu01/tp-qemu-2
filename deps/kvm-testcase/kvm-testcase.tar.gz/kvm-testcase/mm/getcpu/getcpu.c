/*
 * $Id: t-test1.c,v 1.1.1.1 2003/07/02 16:32:09 matthias.urban Exp $
 * by Wolfram Gloger 1996-1999
 * A multi-thread test for malloc performance, maintaining one pool of
 * allocated bins per thread.
 *
 * Fixed condition variable usage, and ported to windows
 * Steven Fuerst 2009
 */

 #define _GNU_SOURCE    
#define USE_PTHREADS	1
#define USE_MALLOC	0
#define USE_SPROC	0
#define USE_THR		0

/* Testing level */
#ifndef TEST
#define TEST 0
#endif

#define N_TOTAL		20
//#define N_TOTAL		500
#ifndef N_THREADS
//#define N_THREADS	1
#define N_THREADS	20
#endif
#ifndef N_TOTAL_PRINT
#define N_TOTAL_PRINT 50
#endif
#define STACKSIZE	32768
#ifndef MEMORY
#define MEMORY		(1ULL << 20)
#endif

#define MSIZE		10000
#define I_MAX		10000
#define ACTIONS_MAX	30

#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <malloc.h>
#include <asm-generic/fcntl.h>
#include <string.h>
#include <limits.h>
#include <sys/param.h>
#include <errno.h>
#include <sys/types.h>
#include <asm/unistd.h>
#include <sys/mman.h>
#ifdef __MIPS64__
#define mb()   __asm__ __volatile__ ("sync" : : : "memory")
#elif __LOONGARCH__
#define mb()   __asm__ __volatile__ ("dbar 0" : : : "memory")
#else
#define mb()
#endif
/*
 * Ultra-fast RNG: Use a fast hash of integers.
 * 2**64 Period.
 * Passes Diehard and TestU01 at maximum settings
 */
static __thread unsigned long long rnd_seed;

static pthread_cond_t finish_cond;
static pthread_mutex_t finish_mutex;

struct thread_st
{
	int bins, max, flags;
	size_t size;
	pthread_t id;
	char *sp;
	size_t seed;
   	int tid;
   	int exec;
};

#define __libc_use_alloca(n) 0


pid_t gettid (void)
{
        return syscall(__NR_gettid);
}

static char *
next_line (int fd, char *const buffer, char **cp, char **re,
           char *const buffer_end)
{
  char *res = *cp;
  char *nl = memchr (*cp, '\n', *re - *cp);
  if (nl == NULL)
    {
      if (*cp != buffer)
        {
          if (*re == buffer_end)
            {
              memmove (buffer, *cp, *re - *cp);
              *re = buffer + (*re - *cp);
              *cp = buffer;

              ssize_t n = read(fd, *re, buffer_end - *re);
              if (n < 0)
                return NULL;

              *re += n;

              nl = memchr (*cp, '\n', *re - *cp);
              while (nl == NULL && *re == buffer_end)
                {
                  /* Truncate too long lines.  */
                  *re = buffer + 3 * (buffer_end - buffer) / 4;
                  n = read (fd, *re, buffer_end - *re);
                  if (n < 0)
                    return NULL;

                  nl = memchr (*re, '\n', n);
                  **re = '\n';
                  *re += n;
                }
            }
          else
            nl = memchr (*cp, '\n', *re - *cp);

          res = *cp;
        }

      if (nl == NULL)
        nl = *re - 1;
    }

  *cp = nl + 1;
  //assert (*cp <= *re);

  return res == *re ? NULL : res;
}

#define _U	0x01	/* upper */
#define _L	0x02	/* lower */
#define _D	0x04	/* digit */
#define _C	0x08	/* cntrl */
#define _P	0x10	/* punct */
#define _S	0x20	/* white space (space/lf/tab) */
#define _X	0x40	/* hex digit */
#define _SP	0x80	/* hard space (0x20) */

const unsigned char _ctype[] = {
_C,_C,_C,_C,_C,_C,_C,_C,				/* 0-7 */
_C,_C|_S,_C|_S,_C|_S,_C|_S,_C|_S,_C,_C,			/* 8-15 */
_C,_C,_C,_C,_C,_C,_C,_C,				/* 16-23 */
_C,_C,_C,_C,_C,_C,_C,_C,				/* 24-31 */
_S|_SP,_P,_P,_P,_P,_P,_P,_P,				/* 32-39 */
_P,_P,_P,_P,_P,_P,_P,_P,				/* 40-47 */
_D,_D,_D,_D,_D,_D,_D,_D,				/* 48-55 */
_D,_D,_P,_P,_P,_P,_P,_P,				/* 56-63 */
_P,_U|_X,_U|_X,_U|_X,_U|_X,_U|_X,_U|_X,_U,		/* 64-71 */
_U,_U,_U,_U,_U,_U,_U,_U,				/* 72-79 */
_U,_U,_U,_U,_U,_U,_U,_U,				/* 80-87 */
_U,_U,_U,_P,_P,_P,_P,_P,				/* 88-95 */
_P,_L|_X,_L|_X,_L|_X,_L|_X,_L|_X,_L|_X,_L,		/* 96-103 */
_L,_L,_L,_L,_L,_L,_L,_L,				/* 104-111 */
_L,_L,_L,_L,_L,_L,_L,_L,				/* 112-119 */
_L,_L,_L,_P,_P,_P,_P,_C,				/* 120-127 */
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,			/* 128-143 */
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,			/* 144-159 */
_S|_SP,_P,_P,_P,_P,_P,_P,_P,_P,_P,_P,_P,_P,_P,_P,_P,	/* 160-175 */
_P,_P,_P,_P,_P,_P,_P,_P,_P,_P,_P,_P,_P,_P,_P,_P,	/* 176-191 */
_U,_U,_U,_U,_U,_U,_U,_U,_U,_U,_U,_U,_U,_U,_U,_U,	/* 192-207 */
_U,_U,_U,_U,_U,_U,_U,_P,_U,_U,_U,_U,_U,_U,_U,_L,	/* 208-223 */
_L,_L,_L,_L,_L,_L,_L,_L,_L,_L,_L,_L,_L,_L,_L,_L,	/* 224-239 */
_L,_L,_L,_L,_L,_L,_L,_P,_L,_L,_L,_L,_L,_L,_L,_L};	/* 240-255 */

#define __ismask(x) (_ctype[(int)(unsigned char)(x)])
#define isalpha(c)	((__ismask(c)&(_U|_L)) != 0)
#define isspace(c)	((__ismask(c)&(_S)) != 0)
#define isupper(c)	((__ismask(c)&(_U)) != 0)
#define isxdigit(c)	((__ismask(c)&(_D|_X)) != 0)
#define isdigit(c)	((__ismask(c)&(_D)) != 0)

long long my_strtoll(const char *nptr, char **endptr, register int base) {
	register const char *s = nptr;
	register long long acc;
	register int c;
	register long long cutoff;
	register int neg = 0, any, cutlim;

	do {
		c = *s++;
	} while (isspace(c));
	if (c == '-') {
		neg = 1;
		c = *s++;
	} else if (c == '+')
		c = *s++;
	if ((base == 0 || base == 16) &&
	    c == '0' && (*s == 'x' || *s == 'X')) {
		c = s[1];
		s += 2;
		base = 16;

	}
	if (base == 0)
		base = c == '0' ? 8 : 10;
	cutoff = neg ? -(long long)LLONG_MIN : LLONG_MAX;
	cutlim = cutoff % (long long)base;
	cutoff /= (long long)base;
	for (acc = 0, any = 0;; c = *s++) {
		if (isdigit(c))
			c -= '0';
		else if (isalpha(c))
			c -= isupper(c) ? 'A' - 10 : 'a' - 10;
		else
			break;
		if (c >= base)
			break;
		if (any < 0 || acc > cutoff || (acc == cutoff && c > cutlim))
			any = -1;
		else {
			any = 1;
			acc *= base;
			acc += c;
		}
	}
	if (any < 0) {
		acc = neg ? LLONG_MIN : LLONG_MAX;
		errno = ERANGE;
	} else if (neg)
		acc = -acc;
	if (endptr != 0)
		*endptr = (char *) (any ? s - 1 : nptr);
	return (acc);
}


int my_get_nprocs(void)
{
  static int cached_result;
  static time_t timestamp;
  time_t now = time (NULL);
  time_t prev = timestamp;

  mb();
  if (now == prev)
    return cached_result;

  const size_t buffer_size = __libc_use_alloca (8192) ? 8192 : 512;
  char stack_buf[buffer_size];
  char *buffer = stack_buf;
  char *buffer_end = buffer + buffer_size;
  char *cp = buffer_end;
  char *re = buffer_end;
  const int flags = O_RDONLY;
  int fd;
  char *l;
  int result = 0, size;
 

  memset(buffer, 0, buffer_size); 
#if 0
  fd = open("/sys/devices/system/cpu/online", flags);
  if (fd < 0) {
    printf("fail to open file \n");
    return -1;
  }

  l = next_line (fd, buffer, &cp, &re, buffer_end);
  if (l == NULL)
      goto out;
  close(fd);
#endif 

  memcpy(buffer, "0-3\n", strlen("0-3\n"));
  re = buffer + 4;
  l = buffer;
//  return 4;


  do {
          char *endp;
          unsigned long int m, n;

	  //n = strtoul (l, &endp, 10);
	  n = my_strtoll(l, &endp, 10);
          if (l == endp)
          {
                  result = 0;
                  break;
          }

          m = n;
          if (*endp == '-')
          {
                  l = endp + 1;
                  //m = strtoul (l, &endp, 10);
	  	  m = my_strtoll(l, &endp, 10);
                  if (l == endp)
                  {
                          result = 0;
                          break;
                  }
          }
          result += m - n + 1;
          l = endp;
          while (l < re && isspace (*l))
                  ++l;
  } while (l < re);

out:
  cached_result = result;
  mb();
  timestamp = now;
  return result;
}



static void *malloc_test(void *ptr)
{
	struct thread_st *st = ptr;
	int cpu;
	int   tid;
	pthread_t         self;

	//cpu = get_nprocs();
	cpu = my_get_nprocs();
	if (cpu == 1)
		printf("up system \n");

	self = pthread_self();
	tid = gettid();
	st->tid = tid;

	st->exec = 2;
	pthread_mutex_lock(&finish_mutex);
	st->flags = 1;
	st->exec++;
	mb();
	pthread_cond_signal(&finish_cond);
	pthread_mutex_unlock(&finish_mutex);
	st->exec++;
	return NULL;
}

static int my_start_thread(struct thread_st *st)
{
	pthread_create(&st->id, NULL, malloc_test, st);
	return 0;
}

static int n_total = 0;
static int n_total_max = N_TOTAL;
static int n_running;

static int my_end_thread(struct thread_st *st)
{
	/* Thread st has finished.  Start a new one. */
	if (n_total >= n_total_max)
	{
		n_running--;
		return 0;
	}

	st->seed++;
	my_start_thread(st);
	n_total++;
	if (!(n_total%N_TOTAL_PRINT)) 
		printf("n_total = %d\n", n_total);
	return 0;
}

struct thread_st *st;
int main(int argc, char *argv[])
{
	int i, bins;
	int n_thr = N_THREADS;
	int i_max = I_MAX;
	size_t size = MSIZE;

	if (argc > 1) n_total_max = atoi(argv[1]);
	if (n_total_max < 1) n_thr = 1;
	if (argc > 2) n_thr = atoi(argv[2]);
	if (n_thr < 1) n_thr = 1;
	if (n_thr > 100) n_thr = 100;
	if (argc > 3) i_max = atoi(argv[3]);

	if (argc > 4) size = atol(argv[4]);
	if (size < 2) size = 2;

	bins = MEMORY  /(size * n_thr);
	if (argc > 5) bins = atoi(argv[5]);
	if (bins < 4) bins = 4;

	//mlockall(MCL_CURRENT);
	printf("Using posix threads.\n");
	pthread_cond_init(&finish_cond, NULL);
	pthread_mutex_init(&finish_mutex, NULL);


	st = malloc(n_thr * sizeof(*st));
	if (!st) exit(-1);

	pthread_mutex_lock(&finish_mutex);
	/* Start all n_thr threads. */
	for (i = 0; i < n_thr; i++)
	{
		st[i].bins = bins;
		st[i].max = i_max;
		st[i].size = size;
		st[i].flags = 0;
		st[i].sp = 0;
		st[i].seed = (i_max * size + i) ^ bins;
		if (my_start_thread(&st[i]))
		{
			printf("Creating thread #%d failed.\n", i);
			n_thr = i;
			break;
		}
	}

	printf("total=%d threads=%d i_max=%d size=%ld bins=%d\n",
		   n_total_max, n_thr, i_max, size, bins);
	n_running = n_total = n_thr;
	while ( n_running > 0) {
		/* Wait for subthreads to finish. */
		pthread_cond_wait(&finish_cond, &finish_mutex);
		for (i = 0; i < n_thr; i++)
		{
			if (st[i].flags)
			{
				pthread_join(st[i].id, NULL);
				st[i].flags = 0;
				mb();
				my_end_thread(&st[i]);
			}
		}
	}
	pthread_mutex_unlock(&finish_mutex);

	for (i = 0; i < n_thr; i++)
	{
		if (st[i].sp) free(st[i].sp);
	}
	free(st);
//#if USE_MALLOC
	//malloc_stats();
//#endif
	printf("Done.\n");
	return 0;
}
