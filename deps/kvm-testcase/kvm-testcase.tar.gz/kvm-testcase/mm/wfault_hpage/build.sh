gcc wfault_hpage.c  -g -o wfault_hpage -lpthread
