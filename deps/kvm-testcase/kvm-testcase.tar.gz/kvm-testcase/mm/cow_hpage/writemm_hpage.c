#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/sysinfo.h>
#include <sys/types.h>
#include <sys/wait.h>


typedef void * (* thr_func)(void *);

int *buf;
int bufSize = 0x4000000;
int total_times = 0x1000;
int thread_done = 0;
int thread_count = 4;
int times = 0;
int pagesize;
pthread_mutex_t count_mutex     = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t  condition_var   = PTHREAD_COND_INITIALIZER;
int sum;

#define ADDR (void *)(0x0UL)
#define FLAGS (MAP_PRIVATE | MAP_ANONYMOUS | MAP_HUGETLB)
#define PROTECTION (PROT_READ | PROT_WRITE)
#define HUGEPAGESIZE (0x2000000)


#define MAX_NTHREADS 100
void * run_parallel(int nthreads, thr_func f1, const char *name)
{ 
	pthread_attr_t attr;
	pthread_t thr[MAX_NTHREADS];
	int i;

	printf("Testing %s\n", name);
	if (nthreads > MAX_NTHREADS) {
		fprintf(stderr, "run_parallel: requested too many threads\n");
		abort();
	}

	pthread_attr_init(&attr);
	for (i = 0; i < nthreads; ++i) {
		int code = pthread_create(thr + i, &attr, f1, (void *)(long)i);
		if (code != 0)
		{
			fprintf(stderr, "pthread_create returned %d, thread %d\n", code, i);
			abort();
		}
	}
	for (i = 0; i < nthreads; ++i) {
		int code = pthread_join(thr[i], NULL);
		if (code != 0)
		{
			fprintf(stderr, "pthread_join returned %d, thread %d\n", code, i);
			abort();
		}
	}
	return 0;
}

void * access_mm(void * id)
{
	unsigned long i;
	int len, pid;
	int status;
	int ret = 0;

	sum = 0;
	len = bufSize * sizeof(int);

	/* one thread reading the memory
	 * the other thread write the memory
	 */
	while (times < total_times) {
		i = 0;
		ret = 0;
		pid = fork();

		if (pid == 0) {
			if ((times % 100) == 0)
				printf("times:%#x child ppid:%#x pid:%#x threaid:%#x\r\n", 
					   times, sum, getppid(), getpid(), pthread_self());

			while ( i < bufSize) {
				buf[i] = i;
				sum += buf[i];
				i +=  pagesize;
			}
			munmap(buf, len);
			buf = NULL;
			return 0;
		}

	    waitpid(pid, &status, 0);
		while ( i < bufSize) {
			buf[i] = i;
			sum += buf[i];
			i +=  pagesize;
		}
		pthread_mutex_lock( &count_mutex );
		thread_done++;
		if (thread_done < thread_count) {
			pthread_cond_wait(&condition_var, &count_mutex );
		} else {
			if ((times % 100) == 0)
				printf("times:%#x sum:%#x parent ppid:%#x pid:%#x threaid:%#x\r\n", 
					   times, sum, getppid(), getpid(), pthread_self());
			times++;
			thread_done = 0;
			munmap(buf, len);
			if(0 != ret) {
				printf("munmap failed:%s %d\r\n", strerror(errno), __LINE__);
			}
			else {
				buf = NULL;
				buf = mmap(ADDR, len, PROTECTION, FLAGS, 0, 0);
				if(MAP_FAILED == buf) {
					printf("mmap failed:%s %d\r\n", strerror(errno), __LINE__);
				}		
			}

			pthread_cond_broadcast(&condition_var);
		}
		pthread_mutex_unlock( &count_mutex );
	}
	return 0;
}
int gethugepagesize()
{
	int fd = -1;
    char *pcfilebuf = NULL;
	char *pcfind = NULL;
	int ipagesize = getpagesize();
	int ret = 0;

	fd = open("/proc/meminfo", O_RDONLY, 0);
	if(0 > fd)
	{
		printf("open meminfo failed %s\r\n", strerror(errno));
		return -1;
	}

	pcfilebuf = (char *)malloc(ipagesize);
	if(NULL == pcfilebuf) {
		printf("malloc faile %s\n", strerror(errno));
		close(fd);
		return -1;
	}
	
	read(fd, pcfilebuf, ipagesize);

	printf("%s\n", pcfilebuf);
	pcfind = strstr(pcfilebuf, "Hugepagesize:");
	if(NULL == pcfind) {
		printf("Don't Find 'Hugepagesize' \r\n");
		free(pcfilebuf);
		close(fd);
		return -1;
	}
	
    pcfind = pcfind + strcspn(pcfind, "1234567890");

    sscanf(pcfind, "%d", &pagesize);
	pagesize *= 1024;
	free(pcfilebuf);
	close(fd);

	return 0;
}

int main(void)
{
	int len;
	int ret = 0;
    ret = gethugepagesize();
    if (0 != ret) {
          pagesize = HUGEPAGESIZE;
    }

    printf("get hugepagesizeof %#x ret %d\r\n", pagesize, ret);

	pagesize = pagesize / sizeof(int);
	thread_count = get_nprocs() * 2;
   
	len = bufSize * sizeof(int);
	buf = mmap(ADDR, len, PROTECTION, FLAGS, 0, 0);
	if (buf == MAP_FAILED) {
		fprintf(stderr, "failed to map :%s\n", strerror(errno));
		return -1;
	}
	printf("buf addr %lx size %lx \n", (unsigned long)buf, len);

	run_parallel(thread_count, access_mm, "access_mm");

	munmap(buf, len);

	printf("value of sum %#x\n", sum);
	return 0;
}

