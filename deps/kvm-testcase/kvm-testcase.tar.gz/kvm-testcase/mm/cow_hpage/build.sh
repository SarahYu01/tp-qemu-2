gcc writemm_hpage.c  -g -o writemm_hpage -lpthread
