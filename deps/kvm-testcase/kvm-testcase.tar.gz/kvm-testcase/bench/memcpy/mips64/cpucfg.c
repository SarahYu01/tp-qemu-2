#include <stdio.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/resource.h>

/* Match an individual register number and assign to \var */
#define _IFC_REG(n)             \
        ".ifc   \\r, $" #n "\n\t"       \
        "\\var  = " #n "\n\t"           \
        ".endif\n\t"

__asm__(".macro parse_r var r\n\t"
        "\\var  = -1\n\t"
        _IFC_REG(0)  _IFC_REG(1)  _IFC_REG(2)  _IFC_REG(3)
        _IFC_REG(4)  _IFC_REG(5)  _IFC_REG(6)  _IFC_REG(7)
        _IFC_REG(8)  _IFC_REG(9)  _IFC_REG(10) _IFC_REG(11)
        _IFC_REG(12) _IFC_REG(13) _IFC_REG(14) _IFC_REG(15)
        _IFC_REG(16) _IFC_REG(17) _IFC_REG(18) _IFC_REG(19)
        _IFC_REG(20) _IFC_REG(21) _IFC_REG(22) _IFC_REG(23)
        _IFC_REG(24) _IFC_REG(25) _IFC_REG(26) _IFC_REG(27)
        _IFC_REG(28) _IFC_REG(29) _IFC_REG(30) _IFC_REG(31)
        ".iflt  \\var\n\t"
        ".error \"Unable to parse register name \\r\"\n\t"
        ".endif\n\t"
        ".endm");

static void cpucfg(void)
{   
    __asm__ __volatile__(
                /* Execute cpucfg instruction */
                ".insn \n\t"
                ".word (0xc8080118)\n\t"
                :
                :
                :
    );
}

static inline unsigned int read_cfg(int reg)
{
        unsigned int __res;

        __asm__ __volatile__(
                "parse_r __res,%0\n\t"
                "parse_r reg,%1\n\t"
                ".insn \n\t"
                ".word (0xc8080118 | (reg << 21) | (__res << 11))\n\t"
                :"=r"(__res)
                :"r"(reg)
                :
                );
        return __res;
}

int cpucfgSupported(void)
{
    pid_t pid;
    int status;
    struct rlimit rlimit_new;
    int support_cpucfg = 0;
    int prid;

    rlimit_new.rlim_cur = 0;
    rlimit_new.rlim_max = RLIM_INFINITY;
    pid = fork();

    if (pid > 0) {
        if (waitpid(pid,&status,0) > 0) {
            if (WIFSIGNALED(status))
                /* the child process was terminated by a signal */
                support_cpucfg = 0;
            else
                /* the child process terminated normally*/
                support_cpucfg = 1;
        } else
            support_cpucfg = 0;
    } else if( pid == 0) {

        /* Set core file limit to 0. */
        setrlimit(RLIMIT_CORE, &rlimit_new);
        //cpucfg();
	prid = read_cfg(1);
	exit(0);
    } else 
        support_cpucfg = 0;

    return support_cpucfg;
}
