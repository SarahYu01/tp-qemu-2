#include <stdio.h>
#include <stdlib.h>


static inline void memcpy_align(void *dest, const void *src, size_t n) {
	memcpy(dest, src, n);
}

void memcpy_test(void *dest, const void *src, size_t n) {
	int rem, align, rem1;
	unsigned char *psrc, *pdest;

	align = (unsigned long)src & 0x7;
	if (align) {
		rem = 0x7 - align;
		rem1 = rem;
		
		psrc = src;
		pdest = dest;
		while (rem) {
			*psrc++ = *pdest++;
			rem--;
		}
	}

	dest += rem1;
	src += rem1;
	n -= rem1;
	memcpy_align(dest, src, n);
}


