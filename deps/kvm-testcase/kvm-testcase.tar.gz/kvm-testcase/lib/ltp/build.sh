
CFLAGS="-g -O2 -fno-strict-aliasing -pipe -Wall -W  -Wold-style-definition -I. -D_FORTIFY_SOURCE=2 -I./include"
gcc ${CFLAGS} -c -o tst_cpu.o tst_cpu.c
gcc ${CFLAGS} -c -o tst_fs_type.o tst_fs_type.c
gcc ${CFLAGS} -c -o tst_path_has_mnt_flags.o tst_path_has_mnt_flags.c
gcc ${CFLAGS} -c -o tlibio.o tlibio.c
	
gcc -g -O2 -g -O2 -fno-strict-aliasing -pipe -Wall -W -g -O2 -Wold-style-definition -I. -D_FORTIFY_SOURCE=2 -I./include -I./include -I./include -I./include  -c -o dataascii.o dataascii.c
gcc -g -O2 -g -O2 -fno-strict-aliasing -pipe -Wall -W -g -O2 -Wold-style-definition -I. -D_FORTIFY_SOURCE=2 -I./include -I./include -I./include -I./include  -c -o safe_file_ops.o safe_file_ops.c
gcc -g -O2 -g -O2 -fno-strict-aliasing -pipe -Wall -W -g -O2 -Wold-style-definition -I. -D_FORTIFY_SOURCE=2 -I./include -I./include -I./include -I./include  -c -o tst_fs_has_free.o tst_fs_has_free.c
gcc -g -O2 -g -O2 -fno-strict-aliasing -pipe -Wall -W -g -O2 -Wold-style-definition -I. -D_FORTIFY_SOURCE=2 -I./include -I./include -I./include -I./include  -c -o tst_parse_opts.o tst_parse_opts.c
gcc -g -O2 -g -O2 -fno-strict-aliasing -pipe -Wall -W -g -O2 -Wold-style-definition -I. -D_FORTIFY_SOURCE=2 -I./include -I./include -I./include -I./include  -c -o random_range.o random_range.c
gcc -g -O2 -g -O2 -fno-strict-aliasing -pipe -Wall -W -g -O2 -Wold-style-definition -I. -D_FORTIFY_SOURCE=2 -I./include -I./include -I./include -I./include  -c -o get_path.o get_path.c
gcc -g -O2 -g -O2 -fno-strict-aliasing -pipe -Wall -W -g -O2 -Wold-style-definition -I. -D_FORTIFY_SOURCE=2 -I./include -I./include -I./include -I./include  -c -o tst_fs_link_count.o tst_fs_link_count.c
gcc -g -O2 -g -O2 -fno-strict-aliasing -pipe -Wall -W -g -O2 -Wold-style-definition -I. -D_FORTIFY_SOURCE=2 -I./include -I./include -I./include -I./include  -c -o file_lock.o file_lock.c
gcc -g -O2 -g -O2 -fno-strict-aliasing -pipe -Wall -W -g -O2 -Wold-style-definition -I. -D_FORTIFY_SOURCE=2 -I./include -I./include -I./include -I./include  -c -o safe_stdio.o safe_stdio.c
gcc -g -O2 -g -O2 -fno-strict-aliasing -pipe -Wall -W -g -O2 -Wold-style-definition -I. -D_FORTIFY_SOURCE=2 -I./include -I./include -I./include -I./include  -c -o tst_device.o tst_device.c
gcc -g -O2 -g -O2 -fno-strict-aliasing -pipe -Wall -W -g -O2 -Wold-style-definition -I. -D_FORTIFY_SOURCE=2 -I./include -I./include -I./include -I./include  -c -o tst_timer.o tst_timer.c
gcc -g -O2 -g -O2 -fno-strict-aliasing -pipe -Wall -W -g -O2 -Wold-style-definition -I. -D_FORTIFY_SOURCE=2 -I./include -I./include -I./include -I./include  -c -o write_log.o write_log.c
gcc -g -O2 -g -O2 -fno-strict-aliasing -pipe -Wall -W -g -O2 -Wold-style-definition -I. -D_FORTIFY_SOURCE=2 -I./include -I./include -I./include -I./include  -c -o cloner.o cloner.c
gcc -g -O2 -g -O2 -fno-strict-aliasing -pipe -Wall -W -g -O2 -Wold-style-definition -I. -D_FORTIFY_SOURCE=2 -I./include -I./include -I./include -I./include  -c -o self_exec.o self_exec.c
gcc -g -O2 -g -O2 -fno-strict-aliasing -pipe -Wall -W -g -O2 -Wold-style-definition -I. -D_FORTIFY_SOURCE=2 -I./include -I./include -I./include -I./include  -c -o tst_virt.o tst_virt.c
gcc -g -O2 -g -O2 -fno-strict-aliasing -pipe -Wall -W -g -O2 -Wold-style-definition -I. -D_FORTIFY_SOURCE=2 -I./include -I./include -I./include -I./include  -c -o parse_opts.o parse_opts.c
gcc -g -O2 -g -O2 -fno-strict-aliasing -pipe -Wall -W -g -O2 -Wold-style-definition -I. -D_FORTIFY_SOURCE=2 -I./include -I./include -I./include -I./include  -c -o tst_process_state.o tst_process_state.c
gcc -g -O2 -g -O2 -fno-strict-aliasing -pipe -Wall -W -g -O2 -Wold-style-definition -I. -D_FORTIFY_SOURCE=2 -I./include -I./include -I./include -I./include  -c -o tst_kvercmp.o tst_kvercmp.c
gcc -g -O2 -g -O2 -fno-strict-aliasing -pipe -Wall -W -g -O2 -Wold-style-definition -I. -D_FORTIFY_SOURCE=2 -I./include -I./include -I./include -I./include  -c -o tst_net.o tst_net.c
gcc -g -O2 -g -O2 -fno-strict-aliasing -pipe -Wall -W -g -O2 -Wold-style-definition -I. -D_FORTIFY_SOURCE=2 -I./include -I./include -I./include -I./include  -c -o databin.o databin.c
gcc -g -O2 -g -O2 -fno-strict-aliasing -pipe -Wall -W -g -O2 -Wold-style-definition -I. -D_FORTIFY_SOURCE=2 -I./include -I./include -I./include -I./include  -c -o tst_resource.o tst_resource.c
gcc -g -O2 -g -O2 -fno-strict-aliasing -pipe -Wall -W -g -O2 -Wold-style-definition -I. -D_FORTIFY_SOURCE=2 -I./include -I./include -I./include -I./include  -c -o tst_run_cmd.o tst_run_cmd.c
gcc -g -O2 -g -O2 -fno-strict-aliasing -pipe -Wall -W -g -O2 -Wold-style-definition -I. -D_FORTIFY_SOURCE=2 -I./include -I./include -I./include -I./include  -c -o bytes_by_prefix.o bytes_by_prefix.c
gcc -g -O2 -g -O2 -fno-strict-aliasing -pipe -Wall -W -g -O2 -Wold-style-definition -I. -D_FORTIFY_SOURCE=2 -I./include -I./include -I./include -I./include  -c -o tst_tmpdir.o tst_tmpdir.c
gcc -g -O2 -g -O2 -fno-strict-aliasing -pipe -Wall -W -g -O2 -Wold-style-definition -I. -D_FORTIFY_SOURCE=2 -I./include -I./include -I./include -I./include  -c -o tst_fill_file.o tst_fill_file.c
gcc -g -O2 -g -O2 -fno-strict-aliasing -pipe -Wall -W -g -O2 -Wold-style-definition -I. -D_FORTIFY_SOURCE=2 -I./include -I./include -I./include -I./include  -c -o get_high_address.o get_high_address.c
gcc -g -O2 -g -O2 -fno-strict-aliasing -pipe -Wall -W -g -O2 -Wold-style-definition -I. -D_FORTIFY_SOURCE=2 -I./include -I./include -I./include -I./include  -c -o safe_macros.o safe_macros.c
gcc -g -O2 -g -O2 -fno-strict-aliasing -pipe -Wall -W -g -O2 -Wold-style-definition -I. -D_FORTIFY_SOURCE=2 -I./include -I./include -I./include -I./include  -c -o tst_sig.o tst_sig.c
gcc -g -O2 -g -O2 -fno-strict-aliasing -pipe -Wall -W -g -O2 -Wold-style-definition -I. -D_FORTIFY_SOURCE=2 -I./include -I./include -I./include -I./include  -c -o tst_mkfs.o tst_mkfs.c
gcc -g -O2 -g -O2 -fno-strict-aliasing -pipe -Wall -W -g -O2 -Wold-style-definition -I. -D_FORTIFY_SOURCE=2 -I./include -I./include -I./include -I./include  -c -o pattern.o pattern.c
gcc -g -O2 -g -O2 -fno-strict-aliasing -pipe -Wall -W -g -O2 -Wold-style-definition -I. -D_FORTIFY_SOURCE=2 -I./include -I./include -I./include -I./include  -c -o forker.o forker.c
gcc -g -O2 -g -O2 -fno-strict-aliasing -pipe -Wall -W -g -O2 -Wold-style-definition -I. -D_FORTIFY_SOURCE=2 -I./include -I./include -I./include -I./include  -c -o tst_module.o tst_module.c
gcc -g -O2 -g -O2 -fno-strict-aliasing -pipe -Wall -W -g -O2 -Wold-style-definition -I. -D_FORTIFY_SOURCE=2 -I./include -I./include -I./include -I./include  -c -o open_flags.o open_flags.c
gcc -g -O2 -g -O2 -fno-strict-aliasing -pipe -Wall -W -g -O2 -Wold-style-definition -I. -D_FORTIFY_SOURCE=2 -I./include -I./include -I./include -I./include  -c -o rmobj.o rmobj.c
gcc -g -O2 -g -O2 -fno-strict-aliasing -pipe -Wall -W -g -O2 -Wold-style-definition -I. -D_FORTIFY_SOURCE=2 -I./include -I./include -I./include -I./include  -c -o tst_checkpoint.o tst_checkpoint.c
gcc -g -O2 -g -O2 -fno-strict-aliasing -pipe -Wall -W -g -O2 -Wold-style-definition -I. -D_FORTIFY_SOURCE=2 -I./include -I./include -I./include -I./include  -c -o tst_res.o tst_res.c
gcc -g -O2 -g -O2 -fno-strict-aliasing -pipe -Wall -W -g -O2 -Wold-style-definition -I. -D_FORTIFY_SOURCE=2 -I./include -I./include -I./include -I./include  -c -o tst_pid.o tst_pid.c
gcc -g -O2 -g -O2 -fno-strict-aliasing -pipe -Wall -W -g -O2 -Wold-style-definition -I. -D_FORTIFY_SOURCE=2 -I./include -I./include -I./include -I./include  -c -o datapid.o datapid.c
gcc -g -O2 -g -O2 -fno-strict-aliasing -pipe -Wall -W -g -O2 -Wold-style-definition -I. -D_FORTIFY_SOURCE=2 -I./include -I./include -I./include -I./include  -c -o string_to_tokens.o string_to_tokens.c
ar -rc "libltp.a" tst_cpu.o tst_fs_type.o tst_path_has_mnt_flags.o tlibio.o dataascii.o safe_file_ops.o tst_fs_has_free.o tst_parse_opts.o random_range.o get_path.o tst_fs_link_count.o file_lock.o safe_stdio.o tst_device.o tst_timer.o write_log.o cloner.o self_exec.o tst_virt.o parse_opts.o tst_process_state.o tst_kvercmp.o tst_net.o databin.o tst_resource.o tst_run_cmd.o bytes_by_prefix.o tst_tmpdir.o tst_fill_file.o get_high_address.o safe_macros.o tst_sig.o tst_mkfs.o pattern.o forker.o tst_module.o open_flags.o rmobj.o tst_checkpoint.o tst_res.o tst_pid.o datapid.o string_to_tokens.o
ranlib "libltp.a"
rm -rf *.o
