#include "atomic.h"

int *buf;
int bufSize;
int thread_count = 8;
int fatal = 0;
int times = 0;
int thread_done = 0;
int total_times = 1000;

pthread_mutex_t count_mutex     = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t  condition_var   = PTHREAD_COND_INITIALIZER;

typedef void * (* thr_func)(void *);

void * run_parallel(int nthreads, thr_func f1, const char *name)
{ 
    pthread_attr_t attr;
    pthread_t thr[MAX_NTHREADS];
    int i;

    printf("Testing %s\n", name);
    if (nthreads > MAX_NTHREADS) {
	fprintf(stderr, "run_parallel: requested too many threads\n");
	abort();
    }

    pthread_attr_init(&attr);
    for (i = 0; i < nthreads; ++i) {
	int code = pthread_create(thr + i, &attr, f1, (void *)(long)i);
	if (code != 0)
	{
	    fprintf(stderr, "pthread_create returned %d, thread %d\n", code, i);
	    abort();
	}
    }
    for (i = 0; i < nthreads; ++i) {
	int code = pthread_join(thr[i], NULL);
	if (code != 0)
	{
	    fprintf(stderr, "pthread_join returned %d, thread %d\n", code, i);
	    abort();
	}
    }
    return 0;
}

int main(void)
{
    bufSize = 0x800000;
    buf = malloc(bufSize * sizeof(int));
    memset(buf, 0, bufSize * sizeof(int));
    run_parallel(thread_count, add_and_return, "add_and_return");
    //run_parallel(thread_count, , swap_bitops, "swap_bitops");
    free(buf);
    return 0;
}
