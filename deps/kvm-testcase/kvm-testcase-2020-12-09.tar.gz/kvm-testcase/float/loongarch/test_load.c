#include <stdio.h>
#include <stdlib.h>

void test_ldl_w()
{
    long rj[1];
    long rd, rd2, rd3, rd4;
    rj[0] = 0x1122334455667788;

    asm volatile ("ldl.w %0, %4, 0\n\t"
                  "ldl.w %1, %4, 1\n\t"
                  "ldl.w %2, %4, 2\n\t"
                  "ldl.w %3, %4, 3\n\t"
                    : "=r"(rd), "=r"(rd2), "=r"(rd3), "=r"(rd4)
                    : "r"(rj)
                    : );
    if ((((rd >> 24) & 0xff) == 0x88) &&
         ((rd2 >> 16) == 0x7788) &&
         ((rd3 >> 8) == 0x667788) &&
         (rd4 == 0x55667788))
        printf("PASS: ldl.w  rd 0x%lx,rd2 0x%lx, rd3 0x%lx rd4 0x%lx\n",
               rd, rd2, rd3, rd4);
    else {
        printf("FAIL: ldl.w  rd 0x%lx,rd2 0x%lx, rd3 0x%lx rd4 0x%lx\n",
               rd, rd2, rd3, rd4);
	exit(-1);
    }

}

void test_ldr_w()
{
    long rj[1];
    long rd, rd2, rd3, rd4;
    rj[0] = 0x1122334455667788;

    asm volatile ("ldr.w %0, %4, 0\n\t"
                  "ldr.w %1, %4, 1\n\t"
                  "ldr.w %2, %4, 2\n\t"
                  "ldr.w %3, %4, 3\n\t"
                    : "=r"(rd), "=r"(rd2), "=r"(rd3), "=r"(rd4)
                    : "r"(rj)
                    : );
    if (((rd & 0xffffffff) == 0x55667788) &&
         ((rd2 & 0xffffff) == 0x556677) &&
         ((rd3 & 0xffff) == 0x5566) &&
         ((rd4 & 0xff) == 0x55))
        printf("PASS: ldr.w  rd 0x%lx,rd2 0x%lx, rd3 0x%lx rd4 0x%lx\n",
               rd, rd2, rd3, rd4);
    else {
        printf("FAIL: ldr.w  rd 0x%lx,rd2 0x%lx, rd3 0x%lx rd4 0x%lx\n",
               rd, rd2, rd3, rd4);
	exit(-1);
    }

}

void test_ld_w()
{
    unsigned int rj[4];
    unsigned long rd, rd2;
    rj[0] = 0x80001000;
    rj[1] = 0x12345678;
    rd = rd2 = 0xabcd123456780000;
    asm volatile ("ld.w %0, %2, 0\n\t"
                  "ld.wu %1, %2, 0\n\t"
                   : "=r"(rd), "=r"(rd2)
                   : "r"(rj)
                   : );

    if ((rd == 0xffffffff80001000) && (rd2 == 0x80001000))
        printf("PASS: ld.w/ld.wu high bit is 1 rd 0x%lx rd2 0x%lx\n",
               rd, rd2);
    else {
        printf("FAIL: ld.w/ld.wu high bit is 1 rd 0x%lx rd2 0x%lx\n",
               rd, rd2);
	exit(-1);
    }

    rj[0] = 0x40001000;
    rj[1] = 0x12345678;
    rd = rd2 = 0xabcd123456780000;
    asm volatile ("ld.w %0, %2, 0\n\t"
                  "ld.wu %1, %2, 0\n\t"
                   : "=r"(rd), "=r"(rd2)
                   : "r"(rj)
                   : );

    if ((rd == rd2) && (rd == 0x40001000))
        printf("PASS: ld.w/ld.wu high bit is 0 rd 0x%lx rd2 0x%lx\n",
               rd, rd2);
    else {
        printf("FAIL: ld.w/ld.wu high bit is 0 rd 0x%lx rd2 0x%lx\n",
               rd, rd2);
	exit(-1);
    }

}

int main()
{
    test_ldl_w();
    test_ldr_w();
    test_ld_w();
    return 0;

}
