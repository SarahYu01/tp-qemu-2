#include <stdio.h>
#include <stdlib.h>
#include <math.h>

unsigned long double_to_long(double a)
{
	return *((unsigned long*)&a);
}

static void test_floats_op()
{
	double a = 2.000000;
	double b = 3.000000;

	if (double_to_long(a + b) == 0x4014000000000000)
		printf("PASS:a=%f b=%f a+b=0x%lx\n", a, b, a + b);
	else 
	{
		printf("FAIL:a=%f b=%f a+b=0x%lx\n", a, b, a + b);
		exit(-1);
	}

	if (double_to_long(a - b) == 0xbff0000000000000)
		printf("PASS:a=%f b=%f a-b=0x%lx\n", a, b, a - b);
	else {
		printf("FAIL:a=%f b=%f a-b=0x%lx\n", a, b, a - b);
		exit(-1);
	}

	if (double_to_long(a * b) == 0x4018000000000000)
		printf("PASS:a=%f b=%f a*b=0x%lx\n", a, b, a * b);
	else {
		printf("FAIL:a=%f b=%f a*b=0x%lx\n", a, b, a * b);
		exit(-1);
	}

	if (double_to_long(a / b) == 0x3fe5555555555555){
		printf("PASS:a=%f b=%f a/b=0x%lx\n", a, b, a / b);
	} else {
		printf("FAIL:a=%f b=%f a/b=0x%lx\n", a, b, a / b);
			exit(-1);
	}
	if (double_to_long(fmod(a, b)) == 0x4000000000000000)
		printf("PASS:a=%f b=%f fmod(a, b)=0x%lx\n", a, b, fmod(a, b));
	else {
		printf("FAIL:a=%f b=%f fmod(a, b)=0x%lx\n", a, b, fmod(a, b));
		exit(-1);
	}

	if (double_to_long(sqrt(a)) == 0x3ff6a09e667f3bcd)
		printf("PASS:a=%f sqrt(a)=0x%lx\n", a, sqrt(a));
	else {
		printf("FAIL:a=%f sqrt(a)=0x%lx\n", a, sqrt(a));
		exit(-1);
	}

	if (double_to_long(sin(a)) == 0x3fed18f6ead1b446)
		printf("PASS:a=%f sin(a)=0x%lx\n", a, sin(a));
	else {
		printf("FAIL:a=%f sin(a)=0x%lx\n", a, sin(a));
		exit(-1);
	}

	if (double_to_long(cos(a)) == 0xbfdaa22657537205)
		printf("PASS:a=%f cos(a)=0x%lx\n", a, cos(a));
	else {
		printf("FAIL:a=%f cos(a)=0x%lx\n", a, cos(a));
		exit(-1);
	}

	if (double_to_long(tan(a)) == 0xc0017af62e0950f8)
		printf("PASS:a=%f tan(a)=0x%lx\n", a, tan(a));
	else {
		printf("FAIL:a=%f tan(a)=0x%lx\n", a, tan(a));
		exit(-1);
	}

	if (double_to_long(log(a)) == 0x3fe62e42fefa39ef)
		printf("PASS:a=%f log(a)=0x%lx\n", a, log(a));
	else {
		printf("FAIL:a=%f log(a)=0x%lx\n", a, log(a));
		exit(-1);
	}

	if (double_to_long(exp(a)) == 0x401d8e64b8d4ddae)
		printf("PASS:a=%f exp(a)=0x%lx\n", a, exp(a));
	else {
		printf("FAIL:a=%f exp(a)=0x%lx\n", a, exp(a));
		exit(-1);
	}

	if (double_to_long(atan2(a, b)) == 0x3fe2d0ead6066395)
		printf("PASS:a=%f b=%f atan2(a, b)=0x%lx\n", a, b, atan2(a, b));
	else {
		printf("FAIL:a=%f b=%f atan2(a, b)=0x%lx\n", a, b, atan2(b, b));
		exit(-1);
	}

	if (double_to_long(asin(sin(a))) == 0x3ff243f6a8885a31)
		printf("PASS:a=%f asin(sin(a))=0x%lx\n", a, asin(sin(a)));
	else {
		printf("FAIL:a=%f asin(sin(a))=0x%lx\n", a, asin(sin(a)));
		exit(-1);
	}

	if (double_to_long(acos(cos(a))) == 0x4000000000000000)
		printf("PASS:a=%f acos(cos(a))=0x%lx\n", a, acos(cos(a)));
	else {
		printf("FAIL:a=%f acos(cos(a))=0x%lx\n", a, acos(cos(a)));
		exit(-1);
	}

	if (double_to_long(atan(tan(a))) == 0xbff243f6a8885a30)
		printf("PASS:a=%f atan(tan(a))=0x%lx\n", a, atan(tan(a)));
	else {
		printf("FAIL:a=%f atan(tan(a))=0x%lx\n", a, atan(tan(a)));
		exit(-1);
	}

	a = 1.400000;
	b = -5.000000;

	if (double_to_long(a + b) == 0xc00ccccccccccccd)
		printf("PASS:a=%f b=%f a+b=0x%lx\n", a, b, a + b);
	else {
		printf("FAIL:a=%f b=%f a+b=0x%lx\n", a, b, a + b);
		exit(-1);
	}

	if (double_to_long(a -b) == 0x401999999999999a)
		printf("PASS:a=%f b=%f a-b=0x%lx\n", a, b, a - b);
	else {
		printf("FAIL:a=%f b=%f a-b=0x%lx\n", a, b, a - b);
		exit(-1);
	}

	if (double_to_long(a * b) == 0xc01c000000000000)
		printf("PASS:a=%f b=%f a*b=0x%lx\n", a, b, a * b);
	else {
		printf("FAIL:a=%f b=%f a*b=0x%lx\n", a, b, a * b);
		exit(-1);
	}

	if (double_to_long(a / b) == 0xbfd1eb851eb851eb)
		printf("PASS:a=%f b=%f a/b=0x%lx\n", a, b, a / b);
	else {
		printf("FAIL:a=%f b=%f a/b=0x%lx\n", a, b, a / b);
		exit(-1);
	}

	if (double_to_long(fmod(a, b)) == 0x3ff6666666666666)
		printf("PASS:a=%f b=%f fmod(a, b)=0x%lx\n", a, b, fmod(a, b));
	else {
		printf("FAIL:a=%f b=%f fmod(a, b)=0x%lx\n", a, b, fmod(a, b));
		exit(-1);
	}

	if (double_to_long(sqrt(a)) == 0x3ff2ee73dadc9b57)
		printf("PASS:a=%f sqrt(a)=%lx\n", a, sqrt(a));
	else {
		printf("FAIL:a=%f sqrt(a)=%lx\n", a, sqrt(a));
		exit(-1);
	}

	if (double_to_long(sin(a)) == 0x3fef88cddf44e102)
		printf("PASS:a=%f sin(a)=0x%lx\n", a, sin(a));
	else {
		printf("FAIL:a=%f sin(a)=0x%lx\n", a, sin(a));
		exit(-1);
	}

	if (double_to_long(cos(a)) == 0x3fc5c17bbc13570b)
		printf("PASS:a=%f cos(a)=0x%lx\n", a, cos(a));
	else {
		printf("FAIL:a=%f cos(a)=0x%lx\n", a, cos(a));
		exit(-1);
	}

	if (double_to_long(tan(a)) == 0x401731086dc00a35)
		printf("PASS:a=%f tan(a)=0x%lx\n", a, tan(a));
	else {
		printf("FAIL:a=%f tan(a)=0x%lx\n", a, tan(a));
		exit(-1);
	}

	if (double_to_long(log(a)) == 0x3fd588c2d913348f)
		printf("PASS:a=%f log(a)=0x%lx\n", a, log(a));
	else {
		printf("FAIL:a=%f log(a)=0x%lx\n", a, log(a));
		exit(-1);
	}

	if (double_to_long(exp(a)) == 0x4010388657115a47)
		printf("PASS:a=%f exp(a)=0x%lx\n", a, exp(a));
	else {
		printf("FAIL:a=%f exp(a)=0x%lx\n", a, exp(a));
		exit(-1);
	}

	if (double_to_long(atan2(a, b)) == 0x4006f2dc2469ee06)
		printf("PASS:a=%f b=%f atan2(a, b)=0x%lx\n", a, b, atan2(a, b));
	else {
		printf("FAIL:a=%f b=%f atan2(a, b)=0x%lx\n", a, b, atan2(b, b));
		exit(-1);
	}

	if (double_to_long(asin(sin(a))) == 0x3ff6666666666665)
		printf("PASS:a=%f asin(sin(a))=0x%lx\n", a, asin(sin(a)));
	else {
		printf("FAIL:a=%f asin(sin(a))=0x%lx\n", a, asin(sin(a)));
		exit(-1);
	}

	if (double_to_long(acos(cos(a))) == 0x3ff6666666666666)
		printf("PASS:a=%f acos(cos(a))=0x%lx\n", a, acos(cos(a)));
	else {
		printf("FAIL:a=%f acos(cos(a))=0x%lx\n", a, acos(cos(a)));
		exit(-1);
	}

	if (double_to_long(atan(tan(a))) == 0x3ff6666666666666)
		printf("PASS:a=%f atan(tan(a))=0x%lx\n", a, atan(tan(a)));
	else {
		printf("FAIL:a=%f atan(tan(a))=0x%lx\n", a, atan(tan(a)));
		exit(-1);
	}

}

static void test_maskeqz()
{
	int rd, rj, rk;

	rd = 0;
	rj = 222;
	rk = 333;
	asm volatile ("maskeqz %0, %1, %2\n\t"
			:"=r"(rd)
			:"r"(rj), "r"(rk)
			:);
	if (rd == rj)
		printf("PASS: maskeqz rk !=0 rd,rj is %d %d\n", rd, rj);
	else {
		printf("FAIL: maskeqz rk !=0 rd rj is %d %d\n", rd, rj);
		exit(-1);
	}

	rd = 111;
	rj = 222;
	rk = 0;
	asm volatile ("maskeqz %0, %1, %2\n\t"
			:"=r"(rd)
			:"r"(rj), "r"(rk)
			:);
	if (rd == 0)
		printf("PASS: maskeqz rk = 0 rd, rj is %d %d\n", rd, rj);
	else {
		printf("FAIL: maskeqz rk = 0 rd, rj is %d %d\n", rd, rj);
		exit(-1);
	}

}

static void test_masknez()
{
	int rd, rj, rk;

	rd = 0;
	rj = 222;
	rk = 333;
	asm volatile ("masknez %0, %1, %2\n\t"
			:"=r"(rd)
			:"r"(rj), "r"(rk)
			:);
	if (rd == 0)
		printf("PASS: masknez rk !=0 rd,rj is %d %d\n", rd, rj);
	else {
		printf("FAIL: masknez rk !=0 rd rj is %d %d\n", rd, rj);
		exit(-1);
	}

	rd = 111;
	rj = 222;
	rk = 0;
	asm volatile ("masknez %0, %1, %2\n\t"
			:"=r"(rd)
			:"r"(rj), "r"(rk)
			:);
	if (rd == rj)
		printf("PASS: masknez rk = 0 rd, rj is %d %d\n", rd, rj);
	else {
		printf("FAIL: masknez rk = 0 rd, rj is %d %d\n", rd, rj);
		exit(-1);
	}

}

static void test_frint_s()
{
	float fj = 0xFFFFFFFF;
	float fd = 0;
	asm volatile("frint.s %0,%1\n\t"
			:"=f"(fd)
			:"f"(fj)
			:);
	if (double_to_long(fd) == 0x41f0000000000000)
		printf("PASS: frint_s rd is 0x%lx\n", fd);
	else {
		printf("FAIL: frint_s rd is 0x%lx\n", fd);
		exit(-1);
	}

}

static void test_frint_d()
{
	double fj = 0xFFFFFFFFFFFFFFFF;
	double fd = 0;
	asm volatile("frint.d %0, %1\n\t"
			:"=f"(fd)
			:"f"(fj)
			:);
	if (double_to_long(fd) == 0x43f0000000000000)
		printf("PASS: frint_d 0x%lx\n", fd);
	else {
		printf("FAIL: frint_d 0x%lx\n", fd);
		exit(-1);
	}

}

static void test_pcaddu18i()
{
	unsigned long rd2=0;
	unsigned long rd=0;

	asm volatile ("pcaddu18i %0, 0x8001\n\t"
			"pcaddu18i %1, 0x0\n\t"
			:"=r"(rd), "=r"(rd2)
			:);
	rd = rd -rd2;
	rd2 = (0x8001UL << 18) - 4;
	if (rd == rd2)
		printf("PASS: pcaddu18i rd 0x%lx rd2 0x%lx\n", rd, rd2);
	else {
		printf("FAIL: pcaddu18i rd 0x%lx rd2 0x%lx\n", rd, rd2);
		exit(-1);
	}
}

static void test_revb_2w()
{
	unsigned long  rj = 0x10C021098B710CDE;
	unsigned long rd = 0;

	asm volatile ("revb.2w %0, %1\n\t"
			:"=r"(rd)
			:"r"(rj)
			:);
	if (rd == 0x921c010de0c718b)
		printf("PASS: revb.2w rj,rd is 0x%lx\n", rj, rd);
	else {
		printf("FAIL: revb.2w rj,rd is 0x%lx\n", rj, rd);
		exit(-1);
	}

}

static void test_revh_2w()
{
	unsigned long rj = 0x10C021098B710CDE;
	unsigned long rd = 0;

	asm volatile ("revh.2w %0, %1\n\t"
			:"=r"(rd)
			:"r"(rj)
			:);
	if (rd == 0x210910c00cde8b71)
		printf("PASS: revh.2w rj, rd is 0x%lx\n", rj, rd);
	else {
		printf("FAIL: revh.2w rj, rd is 0x%lx\n", rj, rd);
		exit(-1);
	}

}

static void test_ftintrm()
{
	float fj_s = 0x7FC00000;
	float fd_w = 0;
	double fj_d = 0x7FF8000000000000;
	double fd_l = 0;

	asm volatile ("ftintrm.w.s %0, %1\n\t"
			:"=f"(fd_w)
			:"f"(fj_s)
			:);
	if (isnan(fd_w))
		printf("PASS: ftintrm.w.s fd_w is %f %x\n", fd_w, fd_w);
	else {
		printf("FAIL: ftintrm.w.s fd_w is %f %x\n", fd_w, fd_w);
		exit(-1);
	}

	asm volatile ("ftintrm.w.d %0, %1\n\t"
			:"=f"(fd_w)
			:"f"(fj_d)
			:);
	if (isnan(fd_w))
		printf("PASS: ftintrm.w.d fd_w is %f %x\n", fd_w, fd_w);
	else {
		printf("FAIL: ftintrm.w.d fd_w is %f %x\n", fd_w, fd_w);
		exit(-1);
	}

	asm volatile ("ftintrm.l.s %0, %1\n\t"
			:"=f"(fd_l)
			:"f"(fj_s)
			:);
	if (double_to_long(fd_l) == 0x7fc00000)
		printf("PASS: ftintrm.l.s fd_l is %lf %lx\n", fd_l, fd_l);
	else {
		printf("FAIL: ftintrm.l.s fd_l is %lf %lx\n", fd_l, fd_l);
		exit(-1);
	}

	asm volatile ("ftintrm.l.d %0, %1\n\t"
			:"=f"(fd_l)
			:"f"(fj_d)
			:);
	if (isnan(fd_l))
		printf("PASS: ftintrm.l.d fd_l is %lf %lx\n", fd_l, fd_l);
	else {
		printf("PASS: ftintrm.l.d fd_l is %lf %lx\n", fd_l, fd_l);
		exit(-1);
	}

}

static void test_ftintrne()
{
	float fj_s = 0x7FC00000;
	float fd_w = 0;
	double fj_d = 0x7FF8000000000000;
	double fd_l = 0;

	asm volatile ("ftintrne.w.s %0, %1\n\t"
			:"=f"(fd_w)
			:"f"(fj_s)
			:);
	if (isnan(fd_w))
		printf("PASS: ftintrne.w.s fd_w is %f %x\n", fd_w, fd_w);
	else {
		printf("FAIL: ftintrne.w.s fd_w is %f %x\n", fd_w, fd_w);
		exit(-1);
	}

	asm volatile ("ftintrne.w.d %0, %1\n\t"
			:"=f"(fd_w)
			:"f"(fj_d)
			:);
	if (isnan(fd_w))
		printf("PASS: ftintrne.w.d fd_w is %f %x\n", fd_w, fd_w);
	else {
		printf("FAIL: ftintrne.w.d fd_w is %f %x\n", fd_w, fd_w);
		exit(-1);
	}

	asm volatile ("ftintrne.l.s %0, %1\n\t"
			:"=f"(fd_l)
			:"f"(fj_s)
			:);
	if (double_to_long(fd_l) == 0x7fc00000)
		printf("PASS: ftintrne.l.s fd_l is %lf %lx\n", fd_l, fd_l);
	else {
		printf("FAIL: ftintrne.l.s fd_l is %lf %lx\n", fd_l, fd_l);
		exit(-1);
	}

	asm volatile ("ftintrne.l.d %0, %1\n\t"
			:"=f"(fd_l)
			:"f"(fj_d)
			:);
	if (isnan(fd_l))
		printf("PASS: ftintrne.l.d fd_l is %lf %lx\n", fd_l, fd_l);
	else {
		printf("FAIL: ftintrne.l.d fd_l is %lf %lx\n", fd_l, fd_l);
		exit(-1);
	}

}

static void test_ftintrp()
{
	float fj_s = 0x7FC00000;
	float fd_w = 0;
	double fj_d = 0x7FF8000000000000;
	double fd_l = 0;

	asm volatile ("ftintrp.w.s %0, %1\n\t"
			:"=f"(fd_w)
			:"f"(fj_s)
			:);
	if (isnan(fd_w))
		printf("PASS: ftintrp.w.s fd_w is %f %x\n", fd_w, fd_w);
	else {
		printf("FAIL: ftintrp.w.s fd_w is %f %x\n", fd_w, fd_w );
		exit(-1);
	}

	asm volatile ("ftintrp.w.d %0, %1\n\t"
			:"=f"(fd_w)
			:"f"(fj_d)
			:);
	if (isnan(fd_w))
		printf("PASS: ftintrp.w.d fd_w is %f %x\n", fd_w, fd_w);
	else {
		printf("FAIL: ftintrp.w.d fd_w is %f %x\n", fd_w, fd_w);
		exit(-1);
	}

	asm volatile ("ftintrp.l.s %0, %1\n\t"
			:"=f"(fd_l)
			:"f"(fj_s)
			:);
	if (double_to_long(fd_l) == 0x7fc00000)
		printf("PASS: ftintrp.l.s fd_l is %lf %lx\n", fd_l, fd_l);
	else {
		printf("FAIL: ftintrp.l.s fd_l is %lf %lx\n", fd_l, fd_l);
		exit(-1);
	}

	asm volatile ("ftintrp.l.d %0, %1\n\t"
			:"=f"(fd_l)
			:"f"(fj_d)
			:);
	if (isnan(fd_l))
		printf("PASS: ftintrp.l.d fd_l is %lf %lx\n", fd_l, fd_l);
	else {
		printf("FAIL: ftintrp.l.d fd_l is %lf %lx\n", fd_l, fd_l);
		exit(-1);
	}

}

static void test_ftintrz()
{
	float fj_s = 0x7FC00000;
	float fd_w = 0;
	double fj_d = 0x7FF8000000000000;
	double fd_l = 0;

	asm volatile ("ftintrz.w.s %0, %1\n\t"
			:"=f"(fd_w)
			:"f"(fj_s)
			:);
	if (isnan(fd_w))
		printf("PASS: ftintrz.w.s fd_w is %f %x\n", fd_w, fd_w);
	else {
		printf("FAIL: ftintrz.w.s fd_w is %f %x\n", fd_w, fd_w);
		exit(-1);
	}

	asm volatile ("ftintrz.w.d %0, %1\n\t"
			:"=f"(fd_w)
			:"f"(fj_d)
			:);
	if (isnan(fd_w))
		printf("PASS: ftintrz.w.d fd_w is %f %x\n", fd_w, fd_w);
	else {
		printf("FAIL: ftintrz.w.d fd_w is %f %x\n", fd_w, fd_w);
		exit(-1);
	}

	asm volatile ("ftintrz.l.s %0, %1\n\t"
			:"=f"(fd_l)
			:"f"(fj_s)
			:);
	if (double_to_long(fd_l) == 0x7fc00000)
		printf("PASS: ftintrz.l.s fd_l is %lf %lx\n", fd_l, fd_l);
	else {
		printf("FAIL: ftintrz.l.s fd_l is %lf %lx\n", fd_l, fd_l);
		exit(-1);
	}

	asm volatile ("ftintrz.l.d %0, %1\n\t"
			:"=f"(fd_l)
			:"f"(fj_d)
			:);
	if (isnan(fd_l))
		printf("PASS: ftintrz.l.d fd_l is %lf %lx\n", fd_l, fd_l);
	else {
		printf("FAIL: ftintrz.l.d fd_l is %lf %lx\n", fd_l, fd_l);
		exit(-1);
	}

}

static void test_ftint()
{
	float fj_s = 0x7FC00000;
	float fd_w = 0;
	double fj_d = 0x7FF8000000000000;
	double fd_l = 0;

	asm volatile ("ftint.w.s %0, %1\n\t"
			:"=f"(fd_w)
			:"f"(fj_s)
			:);
	if (isnan(fd_w))
		printf("PASS: ftint.w.s fd_w is %f %x\n", fd_w, fd_w);
	else {
		printf("FAIL: ftint.w.s fd_w is %f %x\n", fd_w, fd_w);
		exit(-1);
	}

	asm volatile ("ftint.w.d %0, %1\n\t"
			:"=f"(fd_w)
			:"f"(fj_d)
			:);
	if (isnan(fd_w))
		printf("PASS: ftint.w.d fd_w is %f %x\n", fd_w, fd_w);
	else {
		printf("FAIL: ftint.w.d fd_w is %f %x\n", fd_w, fd_w);
		exit(-1);
	}

	asm volatile ("ftint.l.s %0, %1\n\t"
			:"=f"(fd_l)
			:"f"(fj_s)
			:);
	if (double_to_long(fd_l) == 0x7fc00000)
		printf("PASS: ftint.l.s fd_l is %lf %lx\n", fd_l, fd_l);
	else {
		printf("FAIL: ftint.l.s fd_l is %lf %lx\n", fd_l, fd_l);
		exit(-1);
	}

	asm volatile ("ftint.l.d %0, %1\n\t"
			:"=f"(fd_l)
			:"f"(fj_d)
			:);
	if (isnan(fd_l))
		printf("PASS: ftint.l.d fd_l is %lf %lx\n", fd_l, fd_l);
	else {
		printf("FAIL: ftint.l.d fd_l is %lf %lx\n", fd_l, fd_l);
		exit(-1);
	}

}

int main()
{
	test_floats_op();
	test_maskeqz();
	test_masknez();
	test_frint_s();
	test_frint_d();
	test_pcaddu18i();
	test_revb_2w();
	test_revh_2w();
	test_ftintrm();
	test_ftintrne();
	test_ftintrp();
	test_ftintrz();
	test_ftint();
	return 0;
}
