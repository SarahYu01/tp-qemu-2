ltppath=../../lib/ltp
CFLAGS="-g -O2 -fno-strict-aliasing -pipe -Wall -W -Wold-style-definition -D_FORTIFY_SOURCE=2"
gcc ${CFLLAGS}  -I${ltppath}/include/    -L${ltppath}   mprotect04.c   -lltp -o mprotect04 
