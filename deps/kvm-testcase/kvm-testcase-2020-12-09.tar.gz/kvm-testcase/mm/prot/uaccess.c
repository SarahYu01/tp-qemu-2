#include <pthread.h>
#include <assert.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <setjmp.h>

#define UNCAC_BASE              0x9000000000000000UL
#define LS_BIOS_ADDR        0x1fc00000

#define DEF_HANDLER SIG_ERR

static volatile int sig_caught;
static sigjmp_buf jmpbuf;

static void def_handler();      /* default signal handler */
static void (*tst_setup_signal(int, void (*)(int))) (int);

static void sighandler(int signal, siginfo_t * info, void *ut)

{               
        sig_caught = signal;

   	//printf("receiving signal %s(%d) received (pid = %d) \n", sig, getpid());
        longjmp(jmpbuf, 1);

	//exit(0);
}

static int setup_signal(int sig, void (*handler) (int)) {
        struct sigaction my_act;
        int ret;

        /* Do not mask SIGSEGV, as we are interested in handling it. */
        my_act.sa_sigaction = handler;
        my_act.sa_flags = SA_SIGINFO | SA_NODEFER;
        sigemptyset(&my_act.sa_mask);

        ret = sigaction(sig, &my_act, NULL);
        if (ret != 0){
	    	printf("setup signal failed for signal %d \n", sig);
                return SIG_ERR;
	}
}

int main()
{
    void *addr;
    int val;

    sig_caught = 0;


    setup_signal(SIGBUS, sighandler);
    setup_signal(SIGABRT, sighandler);
    setup_signal(SIGSEGV, sighandler);

    sigsetjmp(jmpbuf, 1);
    if (sig_caught == 0) {
        addr = (void*) (UNCAC_BASE + LS_BIOS_ADDR);
        val = *(int*)addr;
    } 

    if (sig_caught)
        printf("%s: passed, catching signal %d \n", __FILE__, sig_caught);
    return 0;
}
