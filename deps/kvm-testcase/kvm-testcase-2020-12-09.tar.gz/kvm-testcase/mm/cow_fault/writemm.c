#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <errno.h>



typedef void * (* thr_func)(void *);
typedef int (* test_func)(void);    /* Returns != 0 on success */

int *buf;
int bufSize = 0x4000000;
int total_times = 0x100;
int thread_done = 0;
int thread_count = 4;
int times = 0;
int fatal = 0;
int pagesize;
pthread_mutex_t count_mutex     = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t  condition_var   = PTHREAD_COND_INITIALIZER;
int sum;

#define ADDR (void *)(0x0UL)
//#define FLAGS (MAP_PRIVATE | MAP_ANONYMOUS | MAP_HUGETLB)
#define FLAGS (MAP_PRIVATE | MAP_ANONYMOUS)
#define PROTECTION (PROT_READ | PROT_WRITE)


#define MAX_NTHREADS 100
void * run_parallel(int nthreads, thr_func f1, const char *name)
{ 
	pthread_attr_t attr;
	pthread_t thr[MAX_NTHREADS];
	int i;

	printf("Testing %s\n", name);
	if (nthreads > MAX_NTHREADS) {
		fprintf(stderr, "run_parallel: requested too many threads\n");
		abort();
	}

	pthread_attr_init(&attr);
	for (i = 0; i < nthreads; ++i) {
		int code = pthread_create(thr + i, &attr, f1, (void *)(long)i);
		if (code != 0)
		{
			fprintf(stderr, "pthread_create returned %d, thread %d\n", code, i);
			abort();
		}
	}
	for (i = 0; i < nthreads; ++i) {
		int code = pthread_join(thr[i], NULL);
		if (code != 0)
		{
			fprintf(stderr, "pthread_join returned %d, thread %d\n", code, i);
			abort();
		}
	}
	return 0;
}

void * access_mm(void * id)
{
	unsigned long i, j;
	int len, pid;
	int ret, write;
	int status;

	sum = 0;
	i = 0;
	len = bufSize * sizeof(int);
	write = 0;
	/* one thread reading the memory
	 * the other thread write the memory
	 */
	if ((unsigned long)id & 0x1)
		write = 1;
	while ((times < total_times) && (fatal == 0)) {
		pid = fork();

		if (pid > 0) {
			waitpid(pid, &status, 0);
		} else if (pid == 0) {

			while (i < bufSize) {
				sum += buf[i];
				if (buf[i] != 1)
					printf("memory is changed at %x \n", i);
				buf[i] = i;
				i += pagesize;
			}

			return 0;
		}

		pthread_mutex_lock( &count_mutex );
		thread_done++;
		if (thread_done < thread_count) {
			pthread_cond_wait(&condition_var, &count_mutex);
		} else {
			if ((times % 10) == 0)
				printf("times %d \n", times);
			times++;
			thread_done = 0;
			i = 0;
			while (i < bufSize) {
				if (buf[i] != 1)
					printf("memory is changed at %x \n", i);
				i +=  pagesize;
			}
			munmap(buf, len);

			buf = NULL;
			buf = mmap(ADDR, len, PROTECTION, FLAGS, 0, 0);
			i = 0;
			while (i < bufSize) {
				buf[i] = 1;;
				i +=  pagesize;
			}
			pthread_cond_broadcast(&condition_var);
		}
		pthread_mutex_unlock( &count_mutex );
	}
	return 0;
}

int main(void)
{
	int len, i;

	pagesize = getpagesize();
	pagesize = pagesize / sizeof(int);

	len = bufSize * sizeof(int);
	buf = mmap(ADDR, len, PROTECTION, FLAGS, 0, 0);
	if (buf == MAP_FAILED) {
		fprintf(stderr, "failed to map : %s\n", strerror(errno));
		return -1;
	}
	printf("buf addr %lx size %lx \n", (unsigned long)buf, len);

	i = 0;
	while (i < bufSize) {
		buf[i] = 1;;
		i +=  pagesize;
	}

	run_parallel(thread_count, access_mm, "access_mm");

	munmap(buf, len);

	printf("value of sum %d \n", sum);
	return 0;
}

