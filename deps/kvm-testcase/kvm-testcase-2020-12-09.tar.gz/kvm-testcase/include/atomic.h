#ifndef _ATOMIC_ASM_H
#define _ATOMIC_ASM_H

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

# define likely(x)      __builtin_expect(!!(x), 1)
# define unlikely(x)    __builtin_expect(!!(x), 0)

#define atomic_inc_return(v) atomic_add_return(1, (v))
#define atomic_dec_return(v) atomic_sub_return(-1, (v))
#define ATOMIC_INIT(i)    { (i) }

#define MAX_NTHREADS 100

typedef struct {
    int counter;
} atomic_t;

typedef struct {
    long long counter;
} atomic64_t;

#ifdef __MIPS64__

#include <mips64/atomic.h>

#elif defined (__LOONGARCH__)

#include <loongarch/atomic.h>

#endif

#endif /* _ATOMIC_ASM_H */
